package project;



import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


public class Serialization extends FilesWalk {
	private String filename = "C:\\Users\\Geoffroy\\eclipse-workspace\\Projet POO\\serialization\\";
	
	Serialization(Saving save, String filename) {
		super(filename);
		this.filename += filename;
	}
	
	public void serializationSave() {
		ObjectOutputStream stream;
		try {
			stream = new ObjectOutputStream(new FileOutputStream(filename));
			for (Saving save : getSavings()) {
				stream.writeObject(save);
			}
			stream.close();
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}	
}
