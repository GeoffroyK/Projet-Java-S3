package project;

import java.io.IOException;
import java.io.Serializable;

public class Saving implements Serializable {
	
	private String lien = null;
	private String ext = null;
	private String mime = null;
	private String sign = null;
	private boolean empty;
	private String size = null;
	private String sizePicture = null;
	private String result = null;
	

	public Saving(Informations i, Compare c) throws IOException {
		lien = i.getFile().toString();
		ext = i.getFileExt();
		mime = i.getMimeType();
		sign = i.getSign();
		empty = i.isEmpty();
		size = i.getFormatedSize();
		if(i.isImage()) {
			sizePicture = i.printSize();
		}
		result = c.toString();
	}
	
	public String getLien() {
		return lien;
	}
	public String getMime() {
		return mime;
	}
	public String getSign() {
		return sign;
	}
	public String getSize() {
		return size;
	}
	public String getSizePicture() {
		return sizePicture;
	}
	public String getResult() {
		return result;
	}
	
	public String toString() {
		if(empty == true) {
			return "FICHIER :" + lien + "\nFichier vide !\nExtension :" + ext + "\nTaille : " + size + "\nMime : " + mime + "\n" + result +"\n";
		}
		else if(!(sizePicture == null)) {
			return "FICHIER :" + lien +"\n"+ sizePicture +"Extension :" + ext + "\nTaille : " + size + "\nMime : " + mime + "\n" + result + "\n";
		}
		else {
			return "FICHIER :"+ lien +"\nExtension : " + ext + "\nTaille : " + size + "\nMime : " + mime +  "\n" + result + "\n";
		}	
	}
}
