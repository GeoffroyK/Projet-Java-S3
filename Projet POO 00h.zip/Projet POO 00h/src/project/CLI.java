package project;

import java.io.IOException;


public class CLI {
	 
	 public static void main(String[]args) throws IOException {
		 String lien;
		 Informations i = null;
		 Database d;
		 Compare c = null;
		 if (args.length == 0) {
			 System.out.println("================HELP===================");
			 System.out.println("1) -d analyse arborescence r�pertoires");
			 System.out.println("2) -f analyse et v�rifie (un fichier)");
			 System.out.println("3) -s analyse, v�rifie & sauvegarde (un fichier)");
			 System.out.println("=======================================");
		 }
		 else {
			 final String commande = args[0];

			 switch(commande) {
		 		case "-d":
		 			if(args.length > 1) {
		 				lien = args[1];
		 				FilesWalk f = new FilesWalk(lien);
		 				f.start();
		 				if(args.length == 2) {
		 					f.getAllFiles();
		 				}
		 				else {
		 					if(args[2].contentEquals("-s")) {
		 						f.getAllFilesArgs(args[3]);
		 					}
		 				}
		 			}
					break;
		
		 		case "-f":
		 			if(args.length > 1) {
		 				lien = args[1];
		 				i = new Informations(lien);
		 				System.out.println(i);
		 				d = new Database(i.getFileExt());
		 				try {
		 					c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
		 					System.out.println(c);
		 					if ((args.length > 2) && (args[2].contentEquals("-s"))) {
		 						Logs l = new Logs(i,c.toString());
		 						l.textSave();
		 					}
		 				} catch (IOException e) {
		 					System.err.println(e.getMessage());
		 				}
		 			}
		 			break;

		 		case "-gui" :
		 			new GUI("Scan APP");
		 			break;
		 			
		 		default:
		 			System.err.println("Commande invalide");
			 }
		}
	 }
}
