package project;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Serialization {
	
	private static final String FILENAME = "C:\\Users\\Geoffroy\\eclipse-workspace\\Projet POO\\serialization\\lastSave";
	private ArrayList<Saving> saves = new ArrayList <Saving>();
	
	Serialization(ArrayList<Saving> saves) {
		this.saves = saves;
	}
	
	public void serializationWrite(){
		ObjectOutputStream stream;
		try {
		stream = new ObjectOutputStream(new FileOutputStream(FILENAME));
		for(Saving s : saves) {
			stream.writeObject(s);
		}
		System.out.println("Sauvegarde effectu�e");
		stream.close();
		} catch(FileNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
	
	public String[] serializationRead() {
		String right = "";
		String wrong = "";
		try {
			ObjectInputStream stream = new ObjectInputStream(new FileInputStream(FILENAME));
			Saving save = null;
			while ((save = (Saving) stream.readObject()) != null) {
				if(save.getResult().contentEquals("True\n")) {
					right += save.toString();
				}
				else {
					wrong += save.toString();
				}
			}
			stream.close();
		} catch (EOFException e) {
			System.out.println("End of file reading");
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		String loads[] = {right, wrong};
		return loads;
	}
}