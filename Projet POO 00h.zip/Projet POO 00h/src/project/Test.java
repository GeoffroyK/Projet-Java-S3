package project;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.event.WindowAdapter;






public class Test extends JFrame {
	//private JLabel valueLabel = new JLabel("Veuillez entrer un lien dans la zone de texte de gauche et appuyer sur l'un des boutons pour effectuer l'action associ�e.");
	private JTextField linkField = new JTextField();
	private JTextArea analyseField = new JTextArea();
	private JTextArea analyseFieldFalse = new JTextArea();
	private JScrollPane scrollPane = new JScrollPane(analyseField);
	private JScrollPane scrollPane2 = new JScrollPane(analyseFieldFalse);
	private JButton arboParcours = new JButton("Scan Tree");
	private JButton scan = new JButton("Scan File");
	//private JButton save = new JButton("Save");
	private JButton aide = new JButton("Help");
	private JButton browse = new JButton("Select Path");
	private JButton quitButton = new JButton("Quit");
	private JPanel verticalLayout = new JPanel();
	private JPanel l1 = new JPanel();
	private JPanel l2 = new JPanel();
	private JPanel l3 = new JPanel();
	private JPanel l4 = new JPanel();
	private JPanel l5 = new JPanel();
	private ArrayList<Saving> saves = new ArrayList<Saving>();
	
	public Test(String title) {
		super(title);

		init();

		arboParcours.addActionListener(new ArboParcoursAction());
		scan.addActionListener(new ScanAction());
		//save.addActionListener(new SaveAction());
		aide.addActionListener(new AideAction());
		browse.addActionListener(new BrowseAction());
		quitButton.addActionListener(new QuitAction(this)); 
		addWindowListener(new LoadSave());
	}

	private void init() {
		BorderLayout border = new BorderLayout();
		Container contentPane = getContentPane();
		contentPane.setLayout(border);
		
		linkField.setMaximumSize( linkField.getPreferredSize() );
		linkField.setMaximumSize(
			    new Dimension(Integer.MAX_VALUE,
			    linkField.getPreferredSize().height));
		analyseField.setForeground(Color.GREEN);
		analyseFieldFalse.setForeground(Color.RED);
		
		l1.setLayout(new BoxLayout(l1, BoxLayout.LINE_AXIS));
		l1.add(linkField);
		l1.add(Box.createRigidArea(new Dimension(5, 0)));
		l1.add(browse);
		
		l2.setLayout(new BoxLayout(l2, BoxLayout.LINE_AXIS));
		l2.add(scan);
		l2.add(Box.createRigidArea(new Dimension(5, 0)));
		l2.add(arboParcours);
		
		l3.setLayout(new BoxLayout(l3, BoxLayout.LINE_AXIS));
		l3.add(scrollPane);
		l3.add(Box.createRigidArea(new Dimension(5, 0)));
		l3.add(scrollPane2);
		
		/*l4.setLayout(new BoxLayout(l4, BoxLayout.LINE_AXIS));
		l4.add(save);
		*/
		
		l5.setLayout(new BoxLayout(l5, BoxLayout.LINE_AXIS));
		l5.add(aide);
		l5.add(Box.createRigidArea(new Dimension(5, 0)));
		l5.add(quitButton);
		
		verticalLayout.setLayout(new BoxLayout(verticalLayout, BoxLayout.PAGE_AXIS));
		verticalLayout.add(l1);
		verticalLayout.add(Box.createRigidArea(new Dimension(0, 5)));
		verticalLayout.add(l2);
		verticalLayout.add(Box.createRigidArea(new Dimension(0, 5)));
		verticalLayout.add(l3);
		verticalLayout.add(Box.createRigidArea(new Dimension(0, 5)));
		verticalLayout.add(l4);
		verticalLayout.add(Box.createRigidArea(new Dimension(0, 5)));
		verticalLayout.add(l5);
		
		contentPane.add(verticalLayout);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setSize(new Dimension(550, 500));
		setVisible(true);
	}

	private class LoadSave extends WindowAdapter {
		private String r = null;
		private String w = null;
		public void windowOpened(WindowEvent e) {
			Serialization se = new Serialization(saves);
			String loads[] = se.serializationRead();
			r = (String) loads[0];
			w = (String) loads[1];
			analyseField.append(r);
			analyseFieldFalse.append(w);
		}
	}
	
	private  class ArboParcoursAction implements ActionListener {
		private String tmp = "";
		private String lien = null;
		
		@Override
		public void actionPerformed(ActionEvent e) {

		lien = linkField.getText();
		try {
			FilesWalk f = new FilesWalk(lien);
			ArrayList<String> currentFile = new ArrayList<String>();
			currentFile = f.listDirv2(currentFile, lien);
			for(String st : currentFile) {
				Informations i = new Informations(st);
				tmp += i.toString();
				try {
					Database d = new Database(i.getFileExt());
					Compare c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
					tmp += c.toString();
					if((c.isEqualMime())&&(c.isEqualSign())) {
						analyseField.append(tmp);
						Saving s = new Saving(i, c);
						saves.add(s);
					}
					else {
						analyseFieldFalse.append(tmp);
						Saving s = new Saving(i, c);
						saves.add(s);
					}
					tmp = "";
 					} catch (IOException e2) {
 						System.err.println(e2);
 					}
			}
			Serialization se = new Serialization(saves);
			se.serializationWrite();
		}catch(NullPointerException npe) {
			JOptionPane.showMessageDialog(null, "Selected Folder is not a folder.", "Warning", JOptionPane.INFORMATION_MESSAGE);
		}
		}
	}

	 private class ScanAction implements ActionListener {
		String tmp = "";
		String lien = null;
		@Override
		public void actionPerformed(ActionEvent e) {
 			lien = linkField.getText();
 			Informations i = new Informations(lien);
 			tmp += i.toString();
				try {
				Database d = new Database(i.getFileExt());
				Compare c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
				tmp += c.toString();
				if((c.isEqualMime())&&(c.isEqualSign())) {
					analyseField.setText(tmp);
					analyseFieldFalse.setText("");
				}
				else {
					analyseFieldFalse.setText(tmp);
					analyseField.setText("");
				}
				tmp = "";
				} catch (IOException e1) {
				System.err.println(e1.getMessage());
					JOptionPane.showMessageDialog(null, "Selected File is not a file.", "Warning", JOptionPane.INFORMATION_MESSAGE);
				}
		}
	}

	/*private class SaveAction implements ActionListener {
		String tmp = null;
		String lien = null;
		@Override
		public void actionPerformed(ActionEvent e) {
 			lien = linkField.getText();;
 			Informations i = new Informations(lien);
				try {
				Database d = new Database(i.getFileExt());
				Compare c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
				Saving s = new Saving(i, c);
				//Serialization ser = new Serialization(s,"nouveau");
				//ser.serializationSave();
				//tmp += ser.serializationSave();
				analyseField.setText(tmp);
				} catch (IOException e1) {
				System.err.println(e1.getMessage());
			}
		}

	}*/
	
	private class AideAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "L� tu �cris ce que tu veux mettre dans l'aide", "Aide", JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	private class BrowseAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	        int returnVal = chooser.showOpenDialog(getParent());
	        if(returnVal == JFileChooser.APPROVE_OPTION) {
	            linkField.setText(chooser.getSelectedFile().getPath());
	        }
		}
	}
	
	private class QuitAction implements ActionListener {
		private JFrame window;

		public QuitAction(JFrame window) {
			this.window = window;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			window.dispose();
		}

	}
	
	public ArrayList<Saving> getSaves() {
		return saves;
	}
	
	public static void main(String[] args) {
		new Test("SCAN APP");
	}
}