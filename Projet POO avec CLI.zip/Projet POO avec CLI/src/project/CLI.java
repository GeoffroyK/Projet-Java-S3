package project;

import java.io.IOException;
import java.util.Scanner;

public class CLI {
	 
	 public static void main(String[]args) {
		 @SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		 String lien = "C:\\Users\\Geoffroy\\Desktop\\hello.txt";
		 Informations i = null;
		 Database d;
		 Compare c = null;
		 if (args.length == 0) {
			 System.out.println("================HELP===================");
			 System.out.println("1) -d parcours arborescence fichier    ");
			 System.out.println("2) -f scan un fichier donn�            ");
			 System.out.println("3) -s sauvegarde les r�sultats de scan ");
			 System.out.println("=======================================");
		 }
		 else {
			 final String commande = args[0];
			 switch(commande) {
		 		
		 		case "-d":
		 			System.out.println("Saississez le lien");
		 			lien = sc.nextLine();
		 			FilesWalk f = new FilesWalk(lien);
					break;
		
		 		case "-f":
		 			System.out.println("Saississez le lien");
		 			lien = sc.nextLine();
		 			i = new Informations(lien);
		 			System.out.println(i);
	 				d = new Database(i.getFileExt());
	 				try {
						c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
						System.out.println(c);
	 				} catch (IOException e) {
						System.err.println(e.getMessage());
					}
		 			break;
		 		
		 		case "-s":
		 			System.out.println("Saississez le lien");
		 			lien = sc.nextLine();
		 			i = new Informations(lien);
		 			System.out.println(i);
	 				d = new Database(i.getFileExt());
	 				try {
						c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
						System.out.println(c);
	 				} catch (IOException e) {
						System.err.println(e.getMessage());
					}
	 				Saving s = new Saving(i, c);
	 				Serialization ser = new Serialization(s);
	 				ser.serializationSave();
	 				System.out.println("Sauvegarde effectu�e");
		 			break;
		 		default:
		 			System.err.println("Commande invalide");
			 }
		}
	 }
}
