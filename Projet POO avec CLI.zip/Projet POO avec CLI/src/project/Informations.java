package project;


import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;

import javax.imageio.ImageIO;

import org.apache.tika.Tika;

/**
 * 
 * @author Geoffroy
 *
 */
public class Informations {
	private File file = null;
	private BufferedImage image;

	
	public Informations(String filename) {
		file = new File(filename);
	}
	
	public File getFile() {
		return file;
	}
	
	/**
	 * Extension
	 * @return String
	 */
	public String getFileExt() {
		String filename = file.toString();
        int pos = filename.lastIndexOf(".");
		
        if (pos > -1) {
            return filename.substring(pos);
        } else {
            return filename;
        }
    }
	
	
	/**
	 * Taille
	 * @return String
	 */
    public String getFormatedSize() {
        int size = (int) (this.file.length() / 1024);
        double small = this.file.length();
        if (size > 1024) {
            return (size / 1024) + " Mo";
        } 	

        else if(size > 0) {
        	return  size + " ko"; 
        }
        else {
        	return small + " o";
        }
    }
    
    
    /**
     * Mimetype
     * @return String
     * @throws IOException
     */
    public String getMimeType() throws IOException {
		Tika tika = new Tika();
		String mimetype = tika.detect(file);
		return mimetype;
    }
    
    /**
     * Signature
     * @return String 
     * @throws IOException
     */
    public String getSign() throws IOException {
    	BufferedReader reader = new BufferedReader(new FileReader(file));
    	String st;
    	String tmp = "";
    	while((st = reader.readLine()) != null) {
    		tmp += st;
    	}
    	return tmp;
    }
    
    /**
     * @return String
     */
    public String toString() {
    	if(getFormatedSize().equals("0.0 o")) {
    		System.err.println("Fichier vide !");
    	}
    	try {
    		return "Extension : "+getFileExt()+"\nTaille : "+getFormatedSize()+"\nMime : "+getMimeType();
    	}catch(IOException e) {
    		System.err.println("Erreur");
    	}
    	return("Error !");
    }
}