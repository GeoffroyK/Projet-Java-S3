package test1projet;

public class Mime {

}
