package test1projet;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFileChooser;

/**
 * Cette classe sert a lire les propri�t�s d'un fichier
 * @author Bui Christophe & Mah� Julien
 */
public class FileProperty {

    private File file = null;

    /**
     * Contructeur
     * @param filename dossier+nom du fichier
     */
    public FileProperty(String filename) {
        file = new File(filename);
    }

    /**
     * Lit la date du fichier
     * @return date
     */
    public long getDate() {
        return this.file.lastModified();
    }

    /**
     * Affiche la date du fichier
     * @return date au format dd/m/yyyy H:mm:ss
     */
    public String getFormatedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy H:mm:ss");
        Date d = new Date(this.file.lastModified());
        return sdf.format(d);
    }

    /**
     * Lit la taille du fichier
     * @return unit� byte
     */
    public Long getSize() {
        return this.file.length();
    }

    /**
     * Affiche la taille du fichier
     * @return taille au format xx Ko ou xx Mo
     */
    public String getFormatedSize() {
        int size = (int) (this.file.length() / 1024) + 1;
        if (size > 1024) {
            return (size / 1024) + " Mo";
        } else {
            return size + " ko";
        }
    }

    /**
     * Lit le type du fichier
     * @return par exemple pdf
     */
    public String getType() {
        JFileChooser chooser = new JFileChooser();
        return chooser.getTypeDescription(this.file);
    }

    /**
     * Extraire l'extension du fichier
     * @param filename
     * @return format .xxx
     */
    public static String getFileExt(String filename) {
        int pos = filename.lastIndexOf(".");
        if (pos > -1) {
            return filename.substring(pos);
        } else {
            return filename;
        }
    }
}