package test1projet;

import java.io.IOException;
import java.io.File;
import javax.swing.JFileChooser;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

public class TestExtension {
	public static void main(String[] args) throws IOException {
		String file = "C:\\Users\\Geoffroy\\Desktop\\yo.txt";
		Path source = Paths.get("C:\\\\Users\\\\Geoffroy\\\\Desktop\\\\yo.txt");
		FileProperty fileProperty = new FileProperty(file);
		 System.out.println("Taille: " + fileProperty.getFormatedSize());
		System.out.println("Extension: " + FileProperty.getFileExt(file));
		System.out.println("Mime :"+Files.probeContentType(source));
	}
}