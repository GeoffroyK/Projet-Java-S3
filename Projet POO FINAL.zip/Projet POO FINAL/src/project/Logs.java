package project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.GregorianCalendar;

public class Logs {
	private static final String SAVEPATH = "C:\\Users\\Geoffroy\\eclipse-workspace\\Projet POO\\";
	private static final String EXT = ".txt";
	private GregorianCalendar date = (GregorianCalendar) GregorianCalendar.getInstance();
	private Informations info = null;
	private String state = null;
	private String fileName = null;
	
	
	public GregorianCalendar getDate() {
		return date;
	}
	
	public Informations getInfo() {
		return info;
	}
	
	public String getState() {
		return state;
	}
	
	/**
	 * @param info
	 * @param state
	 * @param fileName
	 */
	public Logs(Informations info, String state, String fileName) {
		this.info = info;
		this.state = state;
		this.fileName = SAVEPATH + fileName + EXT;
	}
	
	public void textSave() {
		try {
			ArrayList<String> previous = new ArrayList<String>();
			File file = new File(fileName);
			if(file.isFile()) {
				BufferedReader reader = new BufferedReader(new FileReader(new File(fileName)));
				String line;
			while((line = reader.readLine()) != null) {
				previous.add(line);
			}
			reader.close();
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(fileName)));
			
			for(String c : previous) {
				writer.write(c);
				writer.newLine();
			}
			writer.write(toString());
			writer.close();
			System.out.println("Log saved in project");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public String toString() {
		try {
			return "["+date.getTime().toString()+"] ; " + fileName + " ; " + info.getFileExt() + " ; " + info.getFormatedSize() + " ; "+info.getMimeType()+" ; " + getState();
		} catch (IOException e) {
			return(e.getMessage());
		}
	}
}
