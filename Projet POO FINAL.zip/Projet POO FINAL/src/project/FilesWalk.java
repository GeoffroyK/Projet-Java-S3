package project;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


/**
 * @author Geoffroy
 *
 */
public class FilesWalk {
	private String dirpath;
	private ArrayList<String> files = new ArrayList<String>();
	private ArrayList<Saving> saves = new ArrayList<Saving>();
	//private ArrayList<String> filesunzip = new ArrayList<String>();
	//private static final String UNZIP = "C:\\Users\\Geoffroy\\eclipse-workspace\\Projet POO\\unzip";
    private String tmp = "";
    
    
	public FilesWalk(String dirpath) {
    	this.dirpath = dirpath;
    }
		
	public void setTmp(String tmp) {
		this.tmp = tmp;
	}
	
	public String getTmp() {
		return tmp;
	}
	
	protected ArrayList<Saving> getSavings() {
		return saves;
	}
	
	public void start() throws IOException {
    	listDir(files, dirpath);
	}
	
	public void start2() throws IOException {
		listDirv2(files, dirpath);
	}
	
	
    /**
     * @param directories
     * @param root
     */
    public void listDir(ArrayList<String> directories, String root) {
    	File f = new File(root);
    	File[] listFiles = f.listFiles();
    	for (int i = 0; i < listFiles.length; i++) {
    		if (listFiles[i].isDirectory()) {
    			listDir(directories, listFiles[i].toString());
    	    }
    	    else {
    	    	directories.add(listFiles[i].toString());
    	    }
    	}
    }
    
    /**
     * @param directories
     * @param root
     * @return
     */
    public ArrayList<String> listDirv2(ArrayList<String> directories, String root) {
    	File f = new File(root);
    	File[] listFiles = f.listFiles();
    	for (int i = 0; i < listFiles.length; i++) {
    		if (listFiles[i].isDirectory()) {
    			listDir(directories, listFiles[i].toString());
    	    }
    	    else {
    	    	directories.add(listFiles[i].toString());
    	    }
    	}
    	return directories;
    }
        
    /**
     * @param ser
     * @throws IOException
     */
    public void getAllFilesArgs(String ser) throws IOException {
    	for(String s : files) {
    		Informations i = new Informations(s);
    		System.out.println(i);
    		Database d = new Database(i);
			System.out.println(d);
			Logs l = new Logs(i,d.toString(), ser);
			l.textSave();
    	}
    }
    
    
    /**
     * @throws IOException
     */
    public void getAllFiles() throws IOException {
    	for(String s : files) {  		
    		Informations i = new Informations(s);
    		System.out.println(i);
    		Database d = new Database(i);
    		System.out.println(d);
			}
    		/*if(i.getFileExt().contentEquals(".zip")) {
    			System.out.println(".zip : D�compression");
    			try {
					Unzip u = new Unzip(s,UNZIP);
					listDir(filesunzip,UNZIP);
					for(String su : filesunzip) {
						Informations iu = new Informations(su);
			    		System.out.println(iu);
			    		System.out.println("\n");
			    		try {
			    			Database d = new Database(i.getFileExt());
							Compare c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
							System.out.println(c);
							Logs l = new Logs(i,c.toString());
							l.textSave();
		 				} catch (IOException e) {
							System.err.println(e.getMessage());
						}
					}
					File toBeDeleted = new File(UNZIP);
					if(!toBeDeleted.exists()) {
						toBeDeleted.mkdir();
					}
					u.erase(toBeDeleted);
					Database d = new Database(i.getFileExt());
					Compare c = new Compare(i.getMimeType(),d.researchMime(),i.getSign(),d.researchSign());
					System.out.println(c);
					Logs l = new Logs(i,c.toString());
					l.textSave();
 				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
    		}*/
    		System.out.println("\n");
    	}
    
    
    public String toString() {
		return getTmp();
	}
}
