package project;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Geoffroy
 *
 */
public class Database {
	private String extension = null;
	private String mimeInput = null;
	private String signInput = null;
	
	private static final String PATH = "C:\\Users\\Geoffroy\\eclipse-workspace\\Projet POO\\database.csv";
	
	/**
	 * @param extension
	 */
	public Database(Informations i) {
		try {
			extension = i.getFileExt();
			mimeInput = i.getMimeType();
			if((!i.isImage() && (!i.getFormatedSize().contains(" Mo")))) {
				signInput = i.getSign();
			}
		} catch (IOException e) {
			System.err.println(e);
		}
	}
	
	public String getExtension() {
		return extension;
	}
	public String getMimeInput() {
		return mimeInput;
	}
	public String getSignInput() {
		return signInput;
	}
	
	/**
	 * @return
	 */
	public String researchMime() {
		try {
			File file = new File(PATH);
			String find = getExtension();
			BufferedReader br = new BufferedReader(new FileReader(file));
			String st;
			String fields[];
			while((st = br.readLine()) != null) {
				fields = st.split(";");
				if(fields[0].contentEquals(find)) {
					br.close();
					return fields[2];
				}
			}
			br.close();
		} catch(IOException e) {
			System.err.println(e);
		}
		return "Not in the database !\n";
	}
	
	/**
	 * @return
	 */
	public String researchSign()	{
		File file = new File(PATH);
		String find = getExtension();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String st;
			String fields[];
			while((st = br.readLine()) != null) {
				fields = st.split(";");
				if(fields[0].contentEquals(find)) {
					br.close();
					return fields[1];
				}
			}
			br.close();
		} catch(IOException e) {
			System.err.println(e);
		}
		return "Not in the database !\n";
	}
	
	public boolean isEqualMime() {
		String m1 = researchMime();
		String m2 = getMimeInput();
		return(m1.contentEquals(m2));
	}
	
	public boolean isEqualSign() {
		if(signInput != null) {
			String s1 = researchSign();
			String s2 = getSignInput();
			int pos = s2.indexOf(s1);
			if(pos >= 0) {
				return true;
			}	
			return false;
		}
		return true;
	}
	
	public String toString() {
		if((isEqualMime() && (isEqualSign()))) {
			return "True\n";
		}
			return "False\n";		
	}
}
