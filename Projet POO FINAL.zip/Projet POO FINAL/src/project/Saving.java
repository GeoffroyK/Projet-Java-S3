package project;

import java.io.IOException;
import java.io.Serializable;

/**
 * @author Geoffroy
 *
 */
public class Saving implements Serializable {
	
	private String lien = null;
	private String ext = null;
	private String mime = null;
	private String sign = null;
	private boolean empty;
	private String size = null;
	private String sizePicture = null;
	private String result = null;
	

	/**
	 * @param i
	 * @param c
	 * @throws IOException
	 */
	public Saving(Informations i, Database d) {
		try {
			lien = i.getFile().toString();
			ext = i.getFileExt();
			mime = i.getMimeType();
			sign = i.getSign();
			empty = i.isEmpty();
			size = i.getFormatedSize();
			if(i.isImage()) {
				sizePicture = i.printSize();
			}
			result = d.toString();
		} catch(IOException e) {
			System.err.println(e);
		}
	}
	
	public String getLien() {
		return lien;
	}
	public String getMime() {
		return mime;
	}
	public String getSign() {
		return sign;
	}
	public String getSize() {
		return size;
	}
	public String getSizePicture() {
		return sizePicture;
	}
	public String getResult() {
		return result;
	}
	
	public String toString() {
		if(empty == true) {
			return "\nFICHIER :" + lien + "\nFichier vide !\nExtension :" + ext + "\nTaille : " + size + "\nMime : " + mime + "\n" + result +"\n";
		}
		else if(!(sizePicture == null)) {
			return "\nFICHIER :" + lien +"\n"+ sizePicture +"Extension :" + ext + "\nTaille : " + size + "\nMime : " + mime + "\n" + result + "\n";
		}
		else {
			return "\nFICHIER :"+ lien +"\nExtension : " + ext + "\nTaille : " + size + "\nMime : " + mime +  "\n" + result + "\n";
		}	
	}
}
