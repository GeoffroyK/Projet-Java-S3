package project;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Unzip {
	private String filename;
	private String destDir;
	
	public Unzip(String filename, String destDir) throws IOException {
		
		this.destDir = destDir;
		this.filename = filename;
		
		File dir = new File(destDir);
        FileInputStream fis = new FileInputStream(filename);
        ZipInputStream zis = new ZipInputStream(fis);
        try {

            ZipEntry entry;

            while ((entry = zis.getNextEntry()) != null) {
                File file = new File(dir, entry.getName());

                if (!file.toPath().normalize().startsWith(dir.toPath())) {
                    throw new IOException("Bad zip entry");
                }
                if (entry.isDirectory()) {
                    file.mkdirs();
                    continue;
                }
                System.out.println("Unzipping to " + file.getAbsolutePath());
                byte[] buffer = new byte[1024];
                file.getParentFile().mkdirs();
                BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(file));
                int count;

                while ((count = zis.read(buffer)) != -1) {
                    out.write(buffer, 0, count);
                }

                out.close();
            }
        } finally {
            zis.close();
        }
    }

	public void erase(File sup) throws IOException {
		File[]allContents = sup.listFiles();
	    if (allContents != null) {
	        for (File file : allContents) {
	            erase(file);
	        }
	    }
	    sup.delete();
	}

	public String getDestDir() {
		return destDir;
	}
	
	public String getFilename() {
		return filename;
	}
	
	public String toString() {
		return destDir;
	}

}

